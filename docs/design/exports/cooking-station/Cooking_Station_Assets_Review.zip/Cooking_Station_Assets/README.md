# 料理台组件审查包

- 设计画布：1440 × 900 px。表中的 X/Y 为当前 Godot 场景设计坐标，不包含运行窗口自适应缩放。
- 场景来源：`res://scenes/cooking_station/cooking_station_ui.tscn`，导出时工作分支：`feature/cooking-station`。
- Figma 参考：https://www.figma.com/design/OUk4C7fCqrzPmnOuzZpYGZ/forlives--magic_kitchen?node-id=292-7590
- 素材来源：当前本地 Godot 项目，保持 `res://assets/` 对应路径。这里没有声称重新从 Figma 下载素材。
- `PNG宽/高` 是原文件像素，`显示框宽/高` 是 Godot 控件框；TextureRect 可能按 `expand_mode` 拉伸，九宫格会重排边角。
- 表内包含场景声明但初始隐藏的素材，供核对；五层盘中小料和成品卷会由交互显示。
- 大小订单的食材图标共用同一组 PNG。小订单运行时由 `cooking_view.gd` 重建列表和图标，素材沿用大订单的 `OrderWrapIcon` / `Icon*`。

## 操作与显示对应

| 输入 | 素材结果 | 高亮位置 | 规则 |
| --- | --- | --- | --- |
| 1 指 | `filling-sliced-roast-duck 1.png` | 数字 1、手势 1、第一张手势卡 | 放鸭片 |
| 2 指 | `Filling_Hawthron Sticks.png` | 数字 2、手势 2、第二张手势卡 | 放山楂条 |
| 3 指 | `filling-scallion-strips 1 (1).png` | 数字 3、手势 3、第二张手势卡 | 放葱丝 |
| 4 指 | `filling-cucumber-strips 1.png` | 数字 4、手势 4、第二张手势卡 | 放黄瓜丝 |
| 5 指 | `Filling_Sause.png` | 数字 5、手势 5、第二张手势卡 | 放甜面酱；最上层 |
| 握拳 | `finished_duck_wrap_plate.png` | 拳头图、第三张手势卡 | 检查当前订单所需食材齐全且无多余食材后卷制 |
| Complete Order | 评分占位场景 | 完成按钮 | 仅卷制完成后可提交 |

食材可按当前订单需求以任意顺序添加；上表数字是手势编码和节点顺序，不代表必须顺序添加。

## 订单配方

| 订单 | 所需食材 |
| --- | --- |
| 01 | 鸭片、山楂、黄瓜、葱丝、甜面酱 |
| 02 | 鸭片、黄瓜、甜面酱 |
| 03 | 鸭片、葱丝、山楂、甜面酱 |
| 04 | 鸭片、黄瓜、山楂、甜面酱 |

详细清单见 `组件实例.md`、`素材文件.md`、`控件布局.md` 和 `manifest.json`。
